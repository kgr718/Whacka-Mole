const hammer = document.querySelector(".hammer")

window.addEventListener("mousemove", e => {
    hammer.style.top = e.pageY + "px"
    hammer.style.left = e.pageX + "px"
})
window.addEventListener("mousedown",() => {
    hammer.classList.add("active")
})
window.addEventListener("mouseup", () => {
    hammer.classList.remove("active")
})

const portals = document.querySelectorAll('.portal');
let score = document.querySelector('.score');
let time = document.querySelector('.time');

let timer = 120;
let hitPosition;
let result = 0

function randomMove(){
    portals.forEach(square=>square.classlist.remove("bakumon"))

    let randomPosition = portals[Math.floor(Math.random()*9)]
    randomPosition.classList.add("bakumon")
    hitPosition = randomPosition.id
}
let interval = setInterval(randomMove, 1000)

portals.forEach(square=>square.
   addEventListener('mousedown',()=>{
        if(square.id===hitPosition){
            result++
            score.textContent = result
        }
   }))

   function gameTimer(){
    timer--
    time.textContent = timerIf(timer===0);{
        alert('gameOver')
        clearInterval(interval)
        clearInterval(gameTimer,1000)
    }
   }